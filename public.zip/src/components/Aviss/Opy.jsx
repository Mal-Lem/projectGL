import React  from "react";
import './Opy.css'
import avatar from '../../assets/avatar.png'
const Opy=()=>{
    return (
        <section className="avis">
            <div className="about">
                <h2><b>Avis</b></h2>
            </div>
            <div className="underline0">
            </div>
            <div className="circles">
                <div class="circle1">
                <div className="text">
                    <img src={avatar} alt="" />
                    <h2>Haichour Asma</h2>
                </div>
                    <p>j ai pour ma part beaucoup
                        apprécié cette formation 
                        malgré quelques petits bémols au niveau 
                        de l administration. Grâce à cette école
                        Grâce à cette école Grâce à cette école
                    </p>
                    
                </div>
                <div class="circle2">
                <div className="text">
                    <img src={avatar} alt="" />
                    <h2>Haichour Asma</h2>
                </div>
                    <p>j ai pour ma part beaucoup
                        apprécié cette formation 
                        malgré quelques petits bémols au niveau 
                        de l administration. Grâce à cette école
                        Grâce à cette école Grâce à cette école
                    </p>
                    
                </div>
                <div class="circle3">
                <div className="text">
                    <img src={avatar} alt="" />
                    <h2>Haichour Asma</h2>
                </div>
                    <p>j ai pour ma part beaucoup
                        apprécié cette formation 
                        malgré quelques petits bémols au niveau 
                        de l administration. Grâce à cette école
                        Grâce à cette école Grâce à cette école
                    </p>
                    
                </div>
            </div>
        </section>
    )
};
export default Opy;
