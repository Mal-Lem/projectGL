import React from 'react'
import './Pop.css'
import { Container,Row,Col } from 'reactstrap';
const Pop = ()=> {
  return (
    <Container>
       <div className="article">
            <h2><b>Populaire</b></h2>
            <div className='underlines'></div>
        </div>
    </Container>
  )
};
export default Pop;