import React from 'react'
import './Article.css'
import { Container,Row,Col } from 'reactstrap';
const Article=()=> {
  return (
    <Container>
        <Row>
            <Col lg='6' md='6'>
                <div className="cart">
                    <div className="cart1">
                        
                    </div>
                    
                    <div className="cart2">
                        
                    </div>
                    <div className="cart3">
                        
                    </div>    
                    <div className="cart3">
                        
                    </div> 
                    <div className="cart3">
                        
                    </div> 
                    <div className="cart3">
                        
                    </div>  
                    <div className="cart3">
                        
                    </div>        
                </div>
            </Col>    

        </Row>
</Container>
  )
}

export default Article