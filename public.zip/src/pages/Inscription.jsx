import React from 'react';

const Inscription = () => {
    return (
        <div>
            
        </div>
    );
}

export default Inscription;
